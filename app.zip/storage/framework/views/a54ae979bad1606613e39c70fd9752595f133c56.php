<?php $__env->startSection('tittle','Dashboard'); ?>

<?php $__env->startSection('glyph'); ?>
    <img id="glyph-header" src="assets/svg/si-glyph-chart-column.svg"/> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="active">Dashboard</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-list'); ?>
<div class="list-group">
    <a href="<?php echo e(route('login')); ?>" class="list-group-item list-group-item-action active">
        <img id="glyph-main" src="assets/svg/si-glyph-chart-column.svg"/> Dashboard
    </a>
    <a href="checkin" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-person-checked.svg"/> Check in Tamu
    </a>
    <a href="booking" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-align-center.svg"/> Booking Manual
    </a>
    <a href="hadir" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-person-public.svg"/> Daftar Hadir
    </a>
    <a href="mahasiswa" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-person-public.svg"/> Daftar Wisudawan
    </a>
    <a href="log" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-document-bullet-list.svg"/> Log
    </a>
    <a href="setting" class="list-group-item list-group-item-action dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <img id="glyph-main" src="assets/svg/si-glyph-gear.svg"/> Setting
    </a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-card'); ?>
    <div class="card">
        <div class="card-header font-weight-bold">
            Overview
        </div>
        <div class="row card-body">
            <div class="col-md-6">
                <div class="border shadow p-3 mb-5 bg-white rounded text-center">
                    <h2><img id="glyph-card" src="assets/svg/si-glyph-person-checked.svg"/> <?php echo e($count_tamu); ?></h2>
                    <h5 class="card-title">Daftar Hadir Tamu</h5>
                </div>
            </div>
            <div class="col-md-6">
                <div class="border shadow p-3 mb-5 bg-white rounded text-center">
                    <h2><img id="glyph-card" src="assets/svg/si-glyph-person-public.svg"/> <?php echo e($count_mhs); ?></h2>
                    <h5 class="card-title">Daftar Wisudawan</h5>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dev\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>