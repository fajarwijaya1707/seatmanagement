<?php $__env->startSection('tittle','checkin'); ?>

<?php $__env->startSection('glyph'); ?>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">
    <img id="glyph-header" src="assets/svg/si-glyph-person-checked.svg"/> 
    <link href="assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="active">Check in Tamu</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-list'); ?>
<div class="list-group">
    <a href="<?php echo e(route('login')); ?>" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-chart-column.svg"/> Dashboard
    </a>
    <a href="checkin" class="list-group-item list-group-item-action active">
        <img id="glyph-main" src="assets/svg/si-glyph-person-checked.svg"/> Check in Tamu
    </a>
    <a href="booking" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-align-center.svg"/> Booking Manual
    </a>
    <a href="hadir" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-person-public.svg"/> Daftar Hadir
    </a>
    <a href="mahasiswa" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-person-public.svg"/> Daftar Wisudawan
    </a>
    <a href="log" class="list-group-item list-group-item-action">
        <img id="glyph-main" src="assets/svg/si-glyph-document-bullet-list.svg"/> Log
    </a>
    <a href="setting" class="list-group-item list-group-item-action dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <img id="glyph-main" src="assets/svg/si-glyph-gear.svg"/> Setting
    </a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-card'); ?>
    <div class="card">
        <div class="card-header font-weight-bold">
           Checkin Tamu
        </div>
        <div class="container">
               
                <form id="form" action="/kursi/update" method="POST">
                  <?php echo csrf_field() ?>
                </form> 
                <br><p align="center" style="height: 5px;">Masukan Nim Wisudawan / wisudawati</p></br>
                 <center> <input type="number" id="nim" style="width: 200px;" >
                  <button type="submit" id="kirim">Cari</button></center>
                  <br><center><h3>Scan Barcode Yang Tertera Di undangan Tamu.</h3></center></br>
                  <canvas ></canvas>
                <!-- JavaScript Libraries -->
            <script src="assets/lib/jquery/jquery.min.js"></script>
            <script src="assets/lib/jquery/jquery-migrate.min.js"></script>
            <script src="assets/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
            <script src="assets/lib/easing/easing.min.js"></script>
            <script src="assets/lib/superfish/hoverIntent.js"></script>
            <script src="assets/lib/superfish/superfish.min.js"></script>
            <script src="assets/lib/wow/wow.min.js"></script>
            <script src="assets/lib/waypoints/waypoints.min.js"></script>
            <script src="assets/lib/counterup/counterup.min.js"></script>
            <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
            <script src="assets/lib/isotope/isotope.pkgd.min.js"></script>
            <script src="assets/lib/lightbox/js/lightbox.min.js"></script>
            <script src="assets/lib/touchSwipe/jquery.touchSwipe.min.js"></script>
            <!-- Contact Form JavaScript File -->
            <script src="assets/contactform/contactform.js"></script>

            <!-- Template Main Javascript File -->
            <script src="assets/js/main.js"></script>
            <script type="text/javascript" src="js/qrcodelib.js"></script>
                <script type="text/javascript" src="js/webcodecamjs.js"></script>
                <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        $("#kirim").click(function(){
                            scan($("#nim").val());
                        });
                    });
                    //var txt = "innerText" in HTMLElement.prototype ? "innerText" : "textContent";
                    var arg = {
                        resultFunction: function(result) {
                            //var aChild = document.createElement('li');
                            //aChild[txt] =  result.code;
                            //document.querySelector('body').appendChild(aChild);
                            if (result.code !== "") {//jika ada barkode
                                scan(result.code);
                            }
                        }
                    };
                    function scan(kode) {
                        swal({
                            title: "Pesan Kursi",
                            icon: "info",
                            buttons: {
                                orang1: {
                                    text: "Sendiri",
                                    value: "1",
                                    closeModal: false
                                },
                                orang2: {
                                    text: "Berdua",
                                    value: "2",
                                    closeModal: false
                                },
                                cancel: true
                            },
                        })

                        .then((tamu) => {
                            if (tamu) {
                                var form = new FormData($("#form")[0]);
                                form.append("code", kode);
                                form.append("tamu", tamu);
                        
                                $.ajax({
                                    type: "POST",
                                    url: "./kursi/update",
                                    dataType: "json",
                                    data : form,
                                    contentType: false,
                                    processData: false,
                                    success: function(response) {
                                        if (response.status === 200) {
                                            window.location.assign("http://127.0.0.1:8000/kursi/print?fajarganteng="+kode);
                                            data = response.keterangan;
                                            text = "Segmen: "+data.segmen+", baris: "+data.baris+", kursi";
                                            
                                            for (let index = 0; index<data.kursi.length; index++) {
                                                text += " "+data.kursi[index]
                                                if (index !== 0 && index === data.kursi.length-2) {
                                                    text += ",";
                                                }
                                                
                                                if (index === data.kursi.length-2) {
                                                    text +=  " dan ";
                                                }
                                            }
                                            swal({
                                                title: "Selamat Datang , Orang Tua/wali Dari Saudara "+response.keterangan.nama,
                                                text:  text,
                                                icon: "success",
                                                button: "Tutup"
                                                
                                            });
                                            
                                        } else {
                                            swal({
                                                title: "Anda gagal masuk!",
                                                text: response.keterangan,
                                                icon: "error",
                                                button: "Tutup"
                                            });
                                        }
                                    },
                                    error: function (jqXHR, exception) {
                                        if (jqXHR.status === 0) {
                                            keterangan = "Not connect (verify network).";
                                        } else if (jqXHR.status == 404) {
                                            keterangan = "Requested page not found.";
                                        } else if (jqXHR.status == 500) {
                                            keterangan = "Internal Server Error.";
                                        } else if (exception === "parsererror") {
                                            keterangan = "Requested JSON parse failed.";
                                        } else if (exception === "timeout") {
                                            keterangan = "Time out error.";
                                        } else if (exception === "abort") {
                                            keterangan = "Ajax request aborted.";
                                        } else {
                                            keterangan = "Uncaught Error ("+jqXHR.responseText+").";
                                        }
                                        swal({
                                            title: "Silahkan coba lagi!",
                                            text: keterangan,
                                            icon: "error",
                                            button: "Tutup"
                                        });
                                    }
                                });
                            }
                        });
                    }
                    new WebCodeCamJS("canvas").init(arg).play();
                </script>
                            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dev\resources\views/checkin/index.blade.php ENDPATH**/ ?>