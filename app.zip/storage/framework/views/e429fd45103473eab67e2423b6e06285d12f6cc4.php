<html>
<head>
    <title>kursi</title>
</head>
<body>
<?php $__currentLoopData = $kursi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="/kursi/update" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="number" name="code" value="16650036">
        <input type="text" name="tamu" value="2">
        <input type="submit" name="simpan"><br>
    </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html> <?php /**PATH C:\xampp\htdocs\seatmanagement\resources\views/tambah_kursi.blade.php ENDPATH**/ ?>