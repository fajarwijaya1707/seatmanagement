<?php $__env->startSection('tittle','Daftar Hadir Tamu'); ?>

<?php $__env->startSection('glyph'); ?>
    <img id="glyph-header" src="/assets/svg/si-glyph-person-checked.svg"/> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="active">Daftar Hadir Tamu</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-list'); ?>
    <div class="list-group">
        <a href="<?php echo e(route('login')); ?>" class="list-group-item list-group-item-action">
            <img id="glyph-main" src="/assets/svg/si-glyph-chart-column.svg"/> Dashboard
        </a>
        <a href="/hadir" class="list-group-item list-group-item-action active">
            <img id="glyph-main" src="/assets/svg/si-glyph-person-checked.svg"/> Daftar Hadir
        </a>
        <a href="/mahasiswa" class="list-group-item list-group-item-action">
            <img id="glyph-main" src="/assets/svg/si-glyph-person-public.svg"/> Daftar Wisudawan
        </a>
        <a href="/log" class="list-group-item list-group-item-action">
            <img id="glyph-main" src="/assets/svg/si-glyph-document-bullet-list.svg"/> Log
        </a>
        <a href="/setting" class="list-group-item list-group-item-action dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img id="glyph-main" src="/assets/svg/si-glyph-gear.svg"/> Setting
        </a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>
    
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-card'); ?>
    <div class="card">
        <div class="card-header font-weight-bold">
            Present List
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <!-- Search form -->
                    <form action='<?php echo e(url()->current()); ?>' method='GET' class="form-inline">
                        <input class="form-control mr-sm-2" name="keyword" type="search" placeholder="Search" aria-label="Search" value="<?php echo e(request('keyword')); ?>">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
                <div class="col-md-6 text-right">
                    
                </div>

                <!-- Graduation table list -->
                <table class="table table-striped">
                    <tr>
                        <th>NO</th>
                        <th>NAMA</th>
                        <th>NO. KURSI</th>
                    </tr>
                    <?php $__currentLoopData = $data_tamu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $tamu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no + $data_tamu->firstItem()); ?></td>
                        <td>Orang Tua / Wali dari <?php echo e($tamu->nama); ?></td>
                        <td>Segmen <?php echo e($tamu->segmen); ?> baris ke-<?php echo e($tamu->baris); ?> no.<?php echo e($tamu->nomor); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($data_tamu->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\seatmanagement\resources\views/guest/index.blade.php ENDPATH**/ ?>