<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TamuController extends Controller
{
    public function index(Request $request)
    {
        $data_tamu = DB::table('booking')
            ->join('mahasiswa', 'booking.status', '=', 'mahasiswa.nim')
            ->select('booking.*', 'mahasiswa.nama')
            ->when($request->keyword, function ($query) use ($request) {
            $query->where('segmen', 'like', "%{$request->keyword}%")
                ->orWhere('baris', 'like', "%{$request->keyword}%")
                ->orWhere('nomor', 'like', "%{$request->keyword}%")
                ->orWhere('status', 'like', "%{$request->keyword}%")
                ->orWhere('nama', 'like', "%{$request->keyword}%")
                ->orWhere('checkin', 'like', "%{$request->keyword}%");
        })->paginate(10);
        $data_tamu->appends($request->only('keyword'));

        return view('guest.index',['data_tamu' => $data_tamu]);
    }

    public function log(Request $request)
    {
        $data_tamu = DB::table('booking')
            ->join('mahasiswa', 'booking.status', '=', 'mahasiswa.nim')
            ->select('booking.*', 'mahasiswa.nama')
            ->where('booking.checkin','=',"sudah masuk")
            ->orderBy('id_booking', 'DESC')
            ->when($request->keyword, function ($query) use ($request) {
            $query->where('segmen', 'like', "%{$request->keyword}%")
                ->orWhere('baris', 'like', "%{$request->keyword}%")
                ->orWhere('nomor', 'like', "%{$request->keyword}%")
                ->orWhere('status', 'like', "%{$request->keyword}%")
                ->orWhere('nama', 'like', "%{$request->keyword}%")
                ;
        })->paginate(10);
        $data_tamu->appends($request->only('keyword'));

        return view('log.index',['data_tamu' => $data_tamu]);
    }
    public function booking(Request $request)
    {
        

        return view('booking.booking');
    }
    public function checkin(Request $request)
    {
        

        return view('checkin.index');
    }
}
