<?php $__env->startSection('content'); ?>
    <header id="header">
        <div class="container">
            <div class="row">
                <div class="col-md-10">
                    <h1><?php echo $__env->yieldContent('glyph'); ?> <?php echo $__env->yieldContent('tittle'); ?></h1>
                </div>
                <div class="col-md-2">
                    
                </div>
            </div>
        </div>
    </header>

    <section id="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <?php echo $__env->yieldContent('breadcrumb'); ?>
            </ol>
        </div>
    </section>

    <section id="main">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->yieldContent('main-list'); ?>
                </div>
                <div class="col-md-9">
                    <?php echo $__env->yieldContent('main-card'); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seatmanagement\resources\views/layouts/master.blade.php ENDPATH**/ ?>