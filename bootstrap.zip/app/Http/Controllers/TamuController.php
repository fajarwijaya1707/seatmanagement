<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TamuController extends Controller
{
    public function index(Request $request)
    {
        $data_tamu = DB::table('booking')
            ->join('mahasiswa', 'booking.status', '=', 'mahasiswa.nim')
            ->select('booking.*', 'mahasiswa.nama')
            ->when($request->keyword, function ($query) use ($request) {
            $query->where('segmen', 'like', "%{$request->keyword}%")
                ->orWhere('baris', 'like', "%{$request->keyword}%")
                ->orWhere('nomor', 'like', "%{$request->keyword}%")
                ->orWhere('status', 'like', "%{$request->keyword}%")
                ->orWhere('nama', 'like', "%{$request->keyword}%")
                ->orWhere('checkin', 'like', "%{$request->keyword}%");
        })->paginate(10);
        $data_tamu->appends($request->only('keyword'));

        return view('guest.index',['data_tamu' => $data_tamu]);
    }

    public function log(Request $request)
    {
        $data_tamu = DB::table('booking')
            ->join('mahasiswa', 'booking.status', '=', 'mahasiswa.nim')
            ->select('booking.*', 'mahasiswa.nama')
            ->where('booking.checkin','=',"sudah masuk")
            ->orderBy('id_booking', 'DESC')
            ->when($request->keyword, function ($query) use ($request) {
            $query->where('segmen', 'like', "%{$request->keyword}%")
                ->orWhere('baris', 'like', "%{$request->keyword}%")
                ->orWhere('nomor', 'like', "%{$request->keyword}%")
                ->orWhere('status', 'like', "%{$request->keyword}%")
                ->orWhere('nama', 'like', "%{$request->keyword}%")
                ;
        })->paginate(10);
        $data_tamu->appends($request->only('keyword'));

        return view('log.index',['data_tamu' => $data_tamu]);
    }
    public function booking(Request $request)
    {
        

        return view('booking.booking');
    }
    public function checkin(Request $request)
    {
        

        return view('checkin.index');
    }
    public function tamusukses(Request $request)
    {
        $nim=$request->nim;
        $data_tamu = DB::table('booking')
            ->join('mahasiswa', 'booking.status', '=', 'mahasiswa.nim')
            ->select('booking.*', 'mahasiswa.nama')
            ->where('booking.status','=',$nim)
            ->when($request->keyword, function ($query) use ($request) {
            $query->where('segmen', 'like', "%{$request->keyword}%")
                ->orWhere('baris', 'like', "%{$request->keyword}%")
                ->orWhere('nomor', 'like', "%{$request->keyword}%")
                ->orWhere('status', 'like', "%{$request->keyword}%")
                ->orWhere('nama', 'like', "%{$request->keyword}%")
                ->orWhere('checkin', 'like', "%{$request->keyword}%");
        })->paginate(10);
        $data_tamu->appends($request->only('keyword'));

        return view('booking.coba',['data_tamu' => $data_tamu]);
    }
    public function tamubooking(Request $request)
    {
      $data_tamu = $request->nim;
        $nim=$request->nim;
    $mahasiswa = DB::table("mahasiswa")->where('nim',$nim)->get();
    if (!empty($mahasiswa[0]))
    {
      $mhs = DB::table('booking')->where('status',$nim)->get();
              if (empty($mhs[0]))
              {
                
                $kursi = DB::table('kursi')->select('jumlah')->where('segmen',"$request->segmen")->orderBy('id_kursi','asc')->get();
                $i  = 0;
                $sg= $request->segmen;
                if($sg == "A"){
                    $k=0;
                }
                elseif($sg == "B"){
                    $k=1;
                }
                elseif($sg == "C"){
                    $k=2;
                }
                else{
                    $k=3;
                }

              $input=$request->kursi;
                $tampung = $input+$kursi[$i]->jumlah;
                while ($tampung > 10) {
                  $tampung = $input+$kursi[$i]->jumlah;
                  if ($tampung > 10) { 
                    $i++;
                    $k+4;
                  }
                }
               
                $relasi=$k+1;
              
                DB::table('kursi')->where('id_kursi', $relasi)->update([
                'jumlah' => $tampung,
                ]);

                $booking = DB::table('kursi')->select('segmen','baris')->where('id_kursi', $relasi)->get();
                $nm = DB::table('mahasiswa')->select('nama')->where('nim', $nim)->get();
                if ($input==1){
                  $nomor = $tampung;
                  foreach($booking as $b){
                    $segmen = $b->segmen;
                    $baris = $b->baris;
                    DB::table('booking')->insert(['segmen'=>$segmen,'baris'=>$baris ,'nomor'=>$nomor, "status"=>$nim,'checkin'=>"Belum Masuk"]);
                    
                  }
                  // $booking = DB::table('booking')->select('segmen','baris','nomor')->where('status', $nim)->get();
            
                  // $pdf = PDF::loadview('cetak',['booking'=>$booking]);
                  // $pdf->download('Tiket-Kursi');

                  return redirect('/bookingsukses?nim='.$nim)->with('success','Booking Kursi berhasil !');
                }
                elseif($input ==2){
                  $nomor1 = $tampung-1;
                  foreach($booking as $b){
                    $segmen = $b->segmen;
                    $baris = $b->baris;
                    DB::table('booking')->insert(['segmen'=>$segmen,'baris'=>$baris ,'nomor'=>$nomor1, "status"=>$nim, 'checkin'=>"Belum Masuk"]);
                  }
                  $nomor = $tampung ;
                  foreach($booking as $b){
                    $segmen = $b->segmen;
                    $baris = $b->baris;
                    DB::table('booking')->insert(['segmen'=>$segmen,'baris'=>$baris ,'nomor'=>$nomor, "status"=>$nim , 'checkin'=>"Belum Masuk"]);
                  }
                  // $booking = DB::table('booking')->select('segmen','baris','nomor')->where('status', $nim)->get();
            
                  // $pdf = PDF::loadview('cetak',['booking'=>$booking]);
                  // $pdf->download('Tiket-Kursi');
                  

                  return redirect('/bookingsukses?nim='.$nim)->with('success','Booking Kursi berhasil !');
              
            } else {
              return redirect('/bookingsukses?nim='.$nim)->with('success','Data/NIM yang Anda Masukan Bukan Peserta Wisuda!');
            }
            }else{
               
                return redirect('/bookingsukses?nim='.$nim)->with('success','Anda Sudah Melakukan Booking Sebelumnya !');
              
  }
  } else {
    return redirect('/bookingsukses?nim='.$nim)->with('success','Data/NIM yang Anda Masukan Bukan Peserta Wisuda!');
  }
    
    // foreach($booking as $b){
    //   $segmen = $b->segmen;
    //   $baris = $b->baris;
    //   DB::table('booking')->insert(['segmen'=>$segmen,'baris'=>$baris]);
    // }
   
  

    // return view('cek',['input'=>$input,'booking' => $booking, 'nomor' => $nomor,'nomor1'=>$nomor1]);
    }
}
